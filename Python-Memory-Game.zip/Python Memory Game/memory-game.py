import random
import string
from tkinter import *

characters = string.ascii_letters + string.digits + string.punctuation
random = ''.join(random.choice(characters) for i in range(6))

root = Tk()
root.title("Memory Game")
root.geometry('200x150')


def DiffEasy():
    root.geometry('200x90')
    diff.destroy()
    easy.destroy()
    moderate.destroy()
    hard.destroy()
    sos.destroy()
    sosText1.destroy()
    sosText2.destroy()
    sosText3.destroy()
    sosText4.destroy()
    remember.config(text="Remember this: " + random)
    root.after(10000, lambda: remember.destroy())
    root.after(10000, lambda: Ready())
    root.after(10000, lambda: check.pack())
    root.after(0, lambda: timer_0.pack())
    root.after(500, lambda: timer_0.destroy())
    root.after(1000, lambda: timer_1.pack())
    root.after(1500, lambda: timer_1.destroy())
    root.after(2000, lambda: timer_2.pack())
    root.after(2500, lambda: timer_2.destroy())
    root.after(3000, lambda: timer_3.pack())
    root.after(3500, lambda: timer_3.destroy())
    root.after(4000, lambda: timer_4.pack())
    root.after(4500, lambda: timer_4.destroy())
    root.after(5000, lambda: timer_5.pack())
    root.after(5500, lambda: timer_5.destroy())
    root.after(6000, lambda: timer_6.pack())
    root.after(6500, lambda: timer_6.destroy())
    root.after(7000, lambda: timer_7.pack())
    root.after(7500, lambda: timer_7.destroy())
    root.after(8000, lambda: timer_8.pack())
    root.after(8500, lambda: timer_8.destroy())
    root.after(9000, lambda: timer_9.pack())
    root.after(9500, lambda: timer_9.destroy())
    root.after(9899, lambda: timer_10.pack())
    root.after(9999, lambda: timer_10.destroy())


def DiffModerate():
    root.geometry('200x90')
    diff.destroy()
    easy.destroy()
    moderate.destroy()
    hard.destroy()
    sos.destroy()
    sosText1.destroy()
    sosText2.destroy()
    sosText3.destroy()
    sosText4.destroy()
    remember.config(text="Remember this: " + random)
    root.after(5000, lambda: remember.destroy())
    root.after(5000, lambda: Ready())
    root.after(5000, lambda: check.pack())
    root.after(0, lambda: timer_0.pack())
    root.after(500, lambda: timer_0.destroy())
    root.after(1000, lambda: timer_1.pack())
    root.after(1500, lambda: timer_1.destroy())
    root.after(2000, lambda: timer_2.pack())
    root.after(2500, lambda: timer_2.destroy())
    root.after(3000, lambda: timer_3.pack())
    root.after(3500, lambda: timer_3.destroy())
    root.after(4000, lambda: timer_4.pack())
    root.after(4500, lambda: timer_4.destroy())
    root.after(4899, lambda: timer_5.pack())
    root.after(4999, lambda: timer_5.destroy())


def DiffHard():
    root.geometry('200x90')
    diff.destroy()
    easy.destroy()
    moderate.destroy()
    hard.destroy()
    sos.destroy()
    sosText1.destroy()
    sosText2.destroy()
    sosText3.destroy()
    sosText4.destroy()
    remember.config(text="Remember this: " + random)
    root.after(2000, lambda: remember.destroy())
    root.after(2000, lambda: Ready())
    root.after(2000, lambda: check.pack())
    root.after(0, lambda: timer_0.pack())
    root.after(500, lambda: timer_0.destroy())
    root.after(1000, lambda: timer_1.pack())
    root.after(1500, lambda: timer_1.destroy())
    root.after(1899, lambda: timer_2.pack())
    root.after(1999, lambda: timer_2.destroy())


def Ready():
    guessTime.pack()
    text.pack()


def Truee():
    guess = text.get(1.0, "end-1c")
    if guess == random:
        trueFalse.config(text="Correct, well done!")
        trueFalse.pack()
    elif guess != random:
        trueFalse.config(text="Incorrect, try again!")
        trueFalse.pack()


def Help():
    sosText1.pack()
    sosText2.pack()
    sosText3.pack()
    sosText4.pack()
    root.geometry('700x250')


diff = Label(root, text="Choose a Difficulty!")
easy = Button(root, text="Easy", command=DiffEasy, fg="#03941b")
moderate = Button(root, text="Medium", command=DiffModerate, fg="#BCB502")
hard = Button(root, text="Hard", command=DiffHard, fg="#ff0000")
remember = Label(root, text="")
guessTime = Label(root, text="What were the Chars?")
text = Text(root, height=1, width=6)
trueFalse = Label(root, text="")
check = Button(root, text="Enter", command=Truee)
sos = Button(root, text="Help", command=Help)
sosText1 = Label(root,
                 text="To start the game, select a difficulty (Easy, Medium, or Hard) to proceed to the next screen. When brought to the level")
sosText2 = Label(root,
                 text="screen, you will be presented with a series of 6 randomly generated characters, which you will have to memorise for a")
sosText3 = Label(root,
                 text="few seconds before the time runs out and brings you to the final screen. In the final screen, you will type the randomly")
sosText4 = Label(root,
                 text="generated characters you just saw in the exact same order and press enter to check if you are correct (CaSe SeNsItIvE).")

timer_0 = Label(root, text="0", fg="#ff0000")
timer_1 = Label(root, text="1", fg="#ff0000")
timer_2 = Label(root, text="2", fg="#ff0000")
timer_3 = Label(root, text="3", fg="#ff0000")
timer_4 = Label(root, text="4", fg="#ff0000")
timer_5 = Label(root, text="5", fg="#ff0000")
timer_6 = Label(root, text="6", fg="#ff0000")
timer_7 = Label(root, text="7", fg="#ff0000")
timer_8 = Label(root, text="8", fg="#ff0000")
timer_9 = Label(root, text="9", fg="#ff0000")
timer_10 = Label(root, text="10", fg="#ff0000")

diff.pack()
easy.pack()
moderate.pack()
hard.pack()
sos.pack()
remember.pack()

root.mainloop()